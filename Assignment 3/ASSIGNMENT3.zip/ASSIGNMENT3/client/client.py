import socket
import sys
from hashlib import sha256

def checkFileIntegrity(filePath, expectedHash):
    with open(filePath, 'rb') as fileStream:
        data = fileStream.read()
    calculatedHash = sha256(data).hexdigest()
    return calculatedHash == expectedHash, calculatedHash

def main(serverAddr, serverPort):
    try:
        clientSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        clientSock.connect((serverAddr, serverPort))
        
        with open('/clientdata/received_file.txt', 'wb') as fileStream:
            data = clientSock.recv(1024)
            while data:
                fileStream.write(data)
                data = clientSock.recv(1024)     
        receivedHash = clientSock.recv(64).decode()
        valid, calculatedHash = checkFileIntegrity('/clientdata/received_file.txt', receivedHash)
        
        if valid:
            print("File received and verified successfully.")
        else:
            print(f"File verification failed. Expected {receivedHash}, got {calculatedHash}")
    
    except Exception as e:
        print(f"An error occurred: {e}")
    
    finally:
        clientSock.close()
        input("Press Enter to exit...")

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: python client.py <server_ip> <server_port>")
        sys.exit(1)
    
    serverAddr = sys.argv[1]
    serverPort = int(sys.argv[2])
    main(serverAddr, serverPort)

