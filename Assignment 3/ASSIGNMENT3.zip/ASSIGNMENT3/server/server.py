import socket
import os
from hashlib import sha256

def createFileAndChecksum(path, size=1024):
    randomData = os.urandom(size)
    with open(path, 'wb') as file:
        file.write(randomData)
    return sha256(randomData).hexdigest()

def initiateServer(port):
    serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serverSocket.bind(('0.0.0.0', port))
    serverSocket.listen(1)
    print(f"Server listening on port {port}")
    while True:
        clientSocket, clientAddr = serverSocket.accept()
        print(f"Connection from {clientAddr}")
        checksum = createFileAndChecksum('/serverdata/file.txt')
        with open('/serverdata/file.txt', 'rb') as file:
            clientSocket.sendall(file.read())
            clientSocket.sendall(checksum.encode())
        clientSocket.close()

if __name__ == '__main__':
    import sys
    port = int(sys.argv[1])
    initiateServer(port)

